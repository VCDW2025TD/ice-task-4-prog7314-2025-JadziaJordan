package vcmsa.projects.email_activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editName = findViewById<EditText>(R.id.editName)
        val editMessage = findViewById<EditText>(R.id.editMessage)
        val btnSend = findViewById<Button>(R.id.btnSend)

        btnSend.setOnClickListener {
            val name = editName.text.toString().trim()
            val message = editMessage.text.toString().trim()
            val recipient = "naidoojadzia@gmail.com" // <-- put your test email here

            if (name.isNotEmpty() && message.isNotEmpty()) {
                // Create the email intent
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:") // only email apps should handle this
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                    putExtra(Intent.EXTRA_SUBJECT, "Message from $name")
                    putExtra(Intent.EXTRA_TEXT, message)
                }

                // Check if there is an email app available, then launch it
                if (intent.resolveActivity(packageManager) != null) {
                    startActivity(intent)
                }

            } else {
                // Show errors if inputs are empty
                if (name.isEmpty()) editName.error = "Enter your name"
                if (message.isEmpty()) editMessage.error = "Enter your message"
            }
        }
    }
}
